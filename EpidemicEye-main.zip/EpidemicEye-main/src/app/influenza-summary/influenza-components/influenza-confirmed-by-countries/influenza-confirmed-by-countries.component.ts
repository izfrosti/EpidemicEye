import { Component } from '@angular/core';

@Component({
  selector: 'app-influenza-confirmed-by-countries',
  templateUrl: './influenza-confirmed-by-countries.component.html',
  styleUrl: './influenza-confirmed-by-countries.component.css'
})
export class InfluenzaConfirmedByCountriesComponent {

}
