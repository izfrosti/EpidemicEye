import { Component } from '@angular/core';

@Component({
  selector: 'app-awareness-page',
  templateUrl: './awareness-page.component.html',
  styleUrl: './awareness-page.component.css'
})
export class AwarenessPageComponent {

  ngOnInit(): void {
    this.runDummy();
  }

  runDummy(): void {

    
  }
}
