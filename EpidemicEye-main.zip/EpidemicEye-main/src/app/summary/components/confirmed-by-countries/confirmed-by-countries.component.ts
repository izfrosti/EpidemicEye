import { Component } from '@angular/core';

@Component({
  selector: 'app-confirmed-by-countries',
  templateUrl: './confirmed-by-countries.component.html',
  styleUrl: './confirmed-by-countries.component.css'
})
export class ConfirmedByCountriesComponent {

}
